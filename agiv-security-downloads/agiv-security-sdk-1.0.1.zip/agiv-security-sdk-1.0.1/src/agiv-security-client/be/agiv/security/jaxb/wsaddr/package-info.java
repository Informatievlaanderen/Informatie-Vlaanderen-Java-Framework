@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.w3.org/2005/08/addressing", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package be.agiv.security.jaxb.wsaddr;
