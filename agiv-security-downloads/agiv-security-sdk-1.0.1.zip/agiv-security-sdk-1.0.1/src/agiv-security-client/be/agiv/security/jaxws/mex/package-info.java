/**
 * JAX-WS Metadata Exchange
 * 
 */
package be.agiv.security.jaxws.mex;
