/**
 * JAX-WS WS-Trust
 * 
 */
package be.agiv.security.jaxws.wstrust;
