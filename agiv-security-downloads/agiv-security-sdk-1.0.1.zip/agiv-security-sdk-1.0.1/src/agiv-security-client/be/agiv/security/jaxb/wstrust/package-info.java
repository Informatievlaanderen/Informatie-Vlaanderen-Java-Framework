@javax.xml.bind.annotation.XmlSchema(namespace = "http://docs.oasis-open.org/ws-sx/ws-trust/200512", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package be.agiv.security.jaxb.wstrust;
