
package be.agiv;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the be.agiv package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ClaimInfo_QNAME = new QName("http://www.agiv.be", "ClaimInfo");
    private final static QName _ArrayOfClaimInfo_QNAME = new QName("http://www.agiv.be", "ArrayOfClaimInfo");
    private final static QName _ClaimInfoName_QNAME = new QName("http://www.agiv.be", "Name");
    private final static QName _ClaimInfoOriginalIssuer_QNAME = new QName("http://www.agiv.be", "OriginalIssuer");
    private final static QName _ClaimInfoIssuer_QNAME = new QName("http://www.agiv.be", "Issuer");
    private final static QName _ClaimInfoValue_QNAME = new QName("http://www.agiv.be", "Value");
    private final static QName _GetDataResponseGetDataResult_QNAME = new QName("http://www.agiv.be", "GetDataResult");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: be.agiv
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetData }
     * 
     */
    public GetData createGetData() {
        return new GetData();
    }

    /**
     * Create an instance of {@link ArrayOfClaimInfo }
     * 
     */
    public ArrayOfClaimInfo createArrayOfClaimInfo() {
        return new ArrayOfClaimInfo();
    }

    /**
     * Create an instance of {@link ClaimInfo }
     * 
     */
    public ClaimInfo createClaimInfo() {
        return new ClaimInfo();
    }

    /**
     * Create an instance of {@link GetDataResponse }
     * 
     */
    public GetDataResponse createGetDataResponse() {
        return new GetDataResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClaimInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.agiv.be", name = "ClaimInfo")
    public JAXBElement<ClaimInfo> createClaimInfo(ClaimInfo value) {
        return new JAXBElement<ClaimInfo>(_ClaimInfo_QNAME, ClaimInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfClaimInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.agiv.be", name = "ArrayOfClaimInfo")
    public JAXBElement<ArrayOfClaimInfo> createArrayOfClaimInfo(ArrayOfClaimInfo value) {
        return new JAXBElement<ArrayOfClaimInfo>(_ArrayOfClaimInfo_QNAME, ArrayOfClaimInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.agiv.be", name = "Name", scope = ClaimInfo.class)
    public JAXBElement<String> createClaimInfoName(String value) {
        return new JAXBElement<String>(_ClaimInfoName_QNAME, String.class, ClaimInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.agiv.be", name = "OriginalIssuer", scope = ClaimInfo.class)
    public JAXBElement<String> createClaimInfoOriginalIssuer(String value) {
        return new JAXBElement<String>(_ClaimInfoOriginalIssuer_QNAME, String.class, ClaimInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.agiv.be", name = "Issuer", scope = ClaimInfo.class)
    public JAXBElement<String> createClaimInfoIssuer(String value) {
        return new JAXBElement<String>(_ClaimInfoIssuer_QNAME, String.class, ClaimInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.agiv.be", name = "Value", scope = ClaimInfo.class)
    public JAXBElement<String> createClaimInfoValue(String value) {
        return new JAXBElement<String>(_ClaimInfoValue_QNAME, String.class, ClaimInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfClaimInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.agiv.be", name = "GetDataResult", scope = GetDataResponse.class)
    public JAXBElement<ArrayOfClaimInfo> createGetDataResponseGetDataResult(ArrayOfClaimInfo value) {
        return new JAXBElement<ArrayOfClaimInfo>(_GetDataResponseGetDataResult_QNAME, ArrayOfClaimInfo.class, GetDataResponse.class, value);
    }

}
