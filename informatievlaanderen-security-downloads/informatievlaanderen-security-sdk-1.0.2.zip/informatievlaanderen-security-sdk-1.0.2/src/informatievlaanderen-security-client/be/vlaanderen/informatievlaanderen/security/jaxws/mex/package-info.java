/**
 * JAX-WS Metadata Exchange
 * 
 */
package be.vlaanderen.informatievlaanderen.security.jaxws.mex;
