/**
 * JAX-WS WS-Trust
 * 
 */
package be.vlaanderen.informatievlaanderen.security.jaxws.wstrust;
