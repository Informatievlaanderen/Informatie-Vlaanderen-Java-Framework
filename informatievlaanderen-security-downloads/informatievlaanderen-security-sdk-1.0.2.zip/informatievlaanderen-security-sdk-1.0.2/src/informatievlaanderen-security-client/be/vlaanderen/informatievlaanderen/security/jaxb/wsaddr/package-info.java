@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.w3.org/2005/08/addressing", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package be.vlaanderen.informatievlaanderen.security.jaxb.wsaddr;
