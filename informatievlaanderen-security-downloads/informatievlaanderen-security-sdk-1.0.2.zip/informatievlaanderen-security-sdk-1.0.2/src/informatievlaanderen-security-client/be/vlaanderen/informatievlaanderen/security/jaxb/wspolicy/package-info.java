@javax.xml.bind.annotation.XmlSchema(namespace = "http://schemas.xmlsoap.org/ws/2004/09/policy", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package be.vlaanderen.informatievlaanderen.security.jaxb.wspolicy;
