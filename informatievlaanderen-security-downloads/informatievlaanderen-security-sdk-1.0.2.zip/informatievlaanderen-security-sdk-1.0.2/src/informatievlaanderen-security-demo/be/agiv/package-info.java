@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.agiv.be", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package be.agiv;
